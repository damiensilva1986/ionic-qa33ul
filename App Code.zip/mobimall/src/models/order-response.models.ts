import {Serializable} from "./serializalble.interface";

export class OrderResponse {
	id: string;
	order_key: string;
}