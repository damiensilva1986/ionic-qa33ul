import {Serializable} from "./serializalble.interface";

export class Currency {
	default: string;
	value: string;
	options: any;
}