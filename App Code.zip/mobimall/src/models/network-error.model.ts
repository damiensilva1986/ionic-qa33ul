export class NetworkError {
    constructor(public message:string){
        
    }
}