import {Serializable} from "./serializalble.interface";

export class ShippingLine {
	id: string;
    title: string;
    description: string;
}