import { Serializable } from "./serializalble.interface";

export class ProductAttribute {
    id: string;
    name: string;
    option: string;
}