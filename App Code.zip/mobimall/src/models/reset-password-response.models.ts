import { Serializable } from "./serializalble.interface";

export class ResetPasswordResponse {
}